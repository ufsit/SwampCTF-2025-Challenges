# SwampCTF-Challenge-2025 (Hidden Message-Board)

## Challenge Intro:
Search for the hidden message somewhere <i>inside</i> this message-board.

## How To Run (Visual Studio Code):
1. New Terminal
2. <code>make first</code>

## How To Run (Docker)
<code>docker run -dp 3000:3000 hidden-messageboard</code>

## Solution (v1):
<details>
  <summary>[Spoiler Warning]</summary>
  
1. Enter <code><img onError=document.getElementById("flagstuff").setAttribute("code","G1v3M3Th3Fl@g!!!!"); src='any-invalid-url.com'></code> into textbox
2. Submit
3. Type anything in the text box to refresh the page
  
</details>

## Solution (v2):
<details>
  <summary>[Spoiler Warning]</summary>
  
1. Inspect Element
2. Find <code>id="flagstuff" code=""</code>
3. Edit as HTML
4. Add change to <code>id="flagstuff" code="G1v3M3Th3Fl@g!!!!"</code>
5. Type anything in the text box to refresh the page
   
</details>
