import logo from './logo.svg';
import './App.css';
import React, { useState } from "react";
import {returnRandomResponses, getFlag } from "./Messages.tsx";

function App() {  
  const defaultValue = "";
  const [currentMessage, setMessageBoxValue] = React.useState(defaultValue);
  const [flagGoesHere, setFlagValue] = useState("");
  const divRef = React.useRef(null);

  const [lotteryNumber, setLotteryNumber] = useState(5);
  const [totalNumbers, setTotalNumber] = useState(100);

  var printFlagSetup = document.getElementById("flagstuff");

  console.log("Flag Will Be Checked")

  function addNewMessages(event){
    event.preventDefault()

    if(currentMessage != ""){
      if(printFlagSetup != undefined){
        printFlagSetup.setAttribute("code", "")
      }

      addNewMessageChance()
      divRef.current.innerHTML = "<b>[swampctfcontestant]: </b>" + currentMessage + "<br>" + divRef.current.innerHTML;
      addNewMessageChance()

      setMessageBoxValue(defaultValue)
    }
  }

  function addNewMessageChance(){
    var willTypeMessage = Math.floor(Math.random() * totalNumbers);

    if(willTypeMessage <= lotteryNumber){
      divRef.current.innerHTML = returnRandomResponses() + divRef.current.innerHTML;
      willTypeMessage = Math.floor(Math.random() * 100);
    }
  }

  function updateMessageBox(newTextBoxValue){
    setMessageBoxValue(newTextBoxValue)
    addNewMessageChance()
  }

  async function checkCode(){
    if(printFlagSetup != undefined){
      console.log(printFlagSetup.getAttribute("code"))

      if(printFlagSetup.getAttribute("code") === "G1v3M3Th3Fl@g!!!!"){
        const flag = await getFlag();
        setFlagValue("[flag]: " + flag);
      }
    }
  }

  checkCode()

  return (
    <div>
      <header className="App-header">
        <h1 className="App-header-text">
          HackerChat
        </h1>
      </header>

      <header className="App-content" >
      
      <h1><u>Text Formatting</u></h1>
      <p>
        Use &lt;b&gt;text&lt;/b&gt; for <b>bold</b> <br></br>
        Use &lt;i&gt;text&lt;/i&gt; for <i>italics</i> <br></br>
        Use &lt;u&gt;text&lt;/u&gt; for <u>underline</u> <br></br>
        Use &lt;br&gt;&lt;/br&gt; for new line <br></br>
        Use &lt;del&gt;&lt;/del&gt; for <del>strikethrough</del> <br></br>
        Use &lt;img src = "url"&gt;&lt;/img&gt; for images: <img src = "https://brandcenter.ufl.edu/wp-content/uploads/2021/10/1280px-University_of_Florida_logo.svg-1-300x57.png" width={250} height={50}></img> <br></br>
        Use &lt;a href = "url"&gt;&lt;a&gt; for <a href = "https://www.youtube.com/watch?v=dQw4w9WgXcQ">links</a> <br></br>
      </p>
    
      <h1><u>New Message</u></h1>
      <textarea className = "App-textbox" placeholder = "Enter New Message..." value={currentMessage} /*onClick={addNewMessageChance}*/ onChange={(e) => updateMessageBox(e.target.value)}> </textarea>

      <div id = "flagstuff" code = ""></div>

      <div style={{display:'none'}}>
      Need to remove flagstuff. code: G1v3M3Th3Fl@g!!!!
      </div>

      <div>
        <form onSubmit={addNewMessages}>
          <button className='App-button' type="submit">
            Post
          </button>
        </form>
      </div>

      <h1><u>All User Messages</u></h1>
      {flagGoesHere}
      <div ref={divRef}></div>

      </header>

      <footer className="App-footer">
      <input type="number" value={lotteryNumber} onChange={(e) => setLotteryNumber(e.target.value)}></input>
      <input type="number" value={totalNumbers} onChange={(e) => setTotalNumber(e.target.value)}></input>
      </footer>
    </div>
  );
}

export default App;
