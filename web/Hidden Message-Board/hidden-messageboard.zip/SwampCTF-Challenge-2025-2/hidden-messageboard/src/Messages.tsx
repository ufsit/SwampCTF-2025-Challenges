import flag from './HiddenData/flag.txt'


  const getRandomUser = () => {
    var randomUserID = Math.floor(Math.random() * 10);

    switch(randomUserID) { 
      case 0: { 
        return "[vanbest]: ";
      } 
      case 1: { 
        return "[hackerman]: "; 
      }  
      case 2: { 
        return "[gatorfan21]: "; 
      } 
      case 3: { 
        return "[gatorhater12]: "; 
      } 
      default: { 
        return "[anon]: ";
      } 
    }
  };

  const getRandomMessage = () => {
    var randomMessageID = Math.floor(Math.random() * 11);

    switch(randomMessageID) { 
      case 0: { 
        return "What? <br>";
      } 
      case 1: { 
        return "SwampCTF is pretty cool. <br>";
      }
      case 2: { 
        return "Have you heard the tragedy of Darth Plagueis the Wise? <br>";
      } 
      case 3: { 
        return "Does anyone know how to solve this challenge?! <br>";
      } 
      case 4: { 
        return "No <br>";
      } 
      case 5: { 
        return "IDK <br>";
      } 
      case 6: { 
        return "Yes <br>";
      } 
      case 7: { 
        return "Maybe... <br>";
      } 
      case 8: { 
        return "Should I join UFSIT? <br>";
      } 
      case 9: { 
        return "DON'T CLICK THE LINK GUYS <br>";
      } 
      default: { 
        return "YES!!1!! <br>";
      } 
    }
  };
  
  export const returnRandomResponses = () => {
    var responseString = getRandomUser() + getRandomMessage();
    return responseString;
  };

  export async function getFlag(){
      var currentFlag = "";
      
      await fetch(flag)
      .then(r => r.text())
      .then(text => {
          currentFlag = text;
      });

      return currentFlag
  };
