<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SwampTech Solutions</title>
    <link rel="stylesheet" href="styles/index.css">
</head>
<body>

<header>
    <h1>SwampTech Solutions</h1>
    <p>Revolutionizing the Future of Tech, One Breakthrough at a Time</p>
</header>
<!-- Note to my fellow devs: STOP SLACKING OR ALBERT WILL HAVE YOUR HEAD -->
<!-- We need to be able to migrate our employees over to this management portal by 6/24 of this year -->
<main>

    <p class="mission-statement"><br>Welcome to SwampTech, where we push the boundaries of what's possible in tech innovation, <br> <br>delivering unparalleled results while maintaining a focus on scalable, future-proof solutions.</p>
    <hr><p><br>Our work-in-progress management board created by our very own inhouse employees awaits you <br><br> Proceed to the login page below to gain access as a Guest until development is complete</p>
    <div class="achievement">
        <p></p>
    </div><br>

    <p><a href="login.php">Login manage your SwampTech employee profile!</a></p>
</main>

<div class="footer">
    <p>Powered by the finest minds in tech (and a single caffeine-fueled intern).</p>
</div>

</body>
</html>
