<?php
// dashboard.php - Regular user dashboard
session_start();

$expected_hash = md5('guest');

if (!isset($_COOKIE['user']) || $_COOKIE['user'] !== $expected_hash) {
    header('Location: login.php');
    exit;
}
?>
<html>
<head>
    <title>Guest Dashboard</title>
    <link rel="stylesheet" href="styles/dashboard.css">
</head>
<body>
    <div class="container">
        <h1>Guest Dashboard</h1>
        <p>Welcome, guest!</p>
        <a class="button" href="adminpage.php">If you are an admin, visit the admin page instead</a><br><br><br>
        <br><hr><br>
        <h2>API Actions</h2>
<form id="apiForm" method="POST" action="apiv2.php">
    <input type="text" id="userInput" name="userInput" placeholder="User ID" required><br>
    <input type="text" id="actionInput" name="actionInput" placeholder="Action" required><br><br>
    <button type="submit" id="getLogsButton">Fetch User Logs</button>
    <button type="submit" id="updateStatusButton">Update User Status</button>
</form>

    </div>
    <script>
// Adding a submit event listener to the form
document.getElementById("apiForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    let userInput = document.getElementById('userInput').value;
    let actionInput = document.getElementById('actionInput').value;
    let actionType = event.submitter.id;

    // Prepare form data to be sent
    let formData = new URLSearchParams({ userInput, actionInput });

    if (actionType === "getLogsButton") {
        fetch('apiv2.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                // Handle success
                console.log("System Logs:", data);
                document.getElementById('userInput').value = '';
                document.getElementById('actionInput').value = '';
            })
            .catch(error => console.error("Error fetching system logs:", error));
    } else if (actionType === "updateStatusButton") {
        fetch('apiv2.php', { method: 'POST', body: formData })
            .then(response => response.json())
            .then(data => {
                // Handle success
                console.log("User Status Updated:", data);
                document.getElementById('userInput').value = '';
                document.getElementById('actionInput').value = '';
            })
            .catch(error => console.error("Error updating user status:", error));
    }
});
</script>
</body>
</html>

