#!/bin/bash
set -e

# Start PHP-FPM in background (it's already configured in the base image)
php-fpm -D

# Start Nginx (in foreground to keep container running)
nginx -g "daemon off;"
