import { Component } from '@angular/core';
import { CookieService } from 'ngx-cookie-service';
import * as CryptoJS from 'crypto-js';

@Component({
  selector: 'app-root',
  providers: [CookieService],
  templateUrl: './app.component.html',
  styleUrl: './app.component.sass'
})
export class AppComponent {
  protected date = new Date();

  constructor(private cookieService: CookieService) {
    const key = 'flagPart2_3'; // Store securely, e.g., in environment variables
    const encryptedFlagPart2 = "U2FsdGVkX1/oCOrv2BF34XQbx7f34cYJ8aA71tr8cl8=";
    const encryptedFlagPart3 = "U2FsdGVkX197aFEtB5VUIBcswkWs4GiFPal6425rsTU=";

    this.cookieService.set(
      'flagPart2',
      CryptoJS.AES.decrypt(encryptedFlagPart2, key).toString(CryptoJS.enc.Utf8),
      {
        expires: 7,
        path: '/',
        secure: true,
        sameSite: 'Strict'
      }
    );

    const customHeader = new Headers();
    customHeader.set("flagPart3", CryptoJS.AES.decrypt(encryptedFlagPart3, key).toString(CryptoJS.enc.Utf8))
    fetch("/favicon.ico", { headers: customHeader })
  }
}
